# Implementation Notes

This ledger records deviations from `design_map.html` and `docs/PLAN.md`.

## 2026-08-12

- Plan: publish the PC API as soon as the Android creation button existed. Territory: the
  published `web/endpoint.json` still advertised `online:false`, V3 was healthy, but the second
  scanner and content gate were unconfigured, so the Android app correctly returned
  `endpoint_offline`. Decision: keep the public endpoint fail-closed, install pinned local
  safety runtimes, and require an actual three-gate health check before any tunnel URL can be
  advertised.
- Plan: use the Windows Defender command-line scanner as the second scanner. Territory: Defender
  on-demand scanning returns `0x800106BA` because V3 is the active antivirus provider, and the
  installed V3 utilities expose no verified one-file CLI exit-code contract. Decision: keep V3
  as the independent real-time gate and use pinned ClamAV 1.5.4 as the explicit second scan.
- Plan: use the content model's smaller INT8 ONNX export. Territory: ONNX Runtime 1.20.1 cannot
  execute that graph's `ConvInteger` node on the available CPU provider. Decision: use the
  standard ONNX export pinned by repository revision and full-file SHA-256; inference errors and
  integrity mismatches remain blocking failures.
- Plan: use the original short connection timeout for every GET. Territory: the first real
  ClamAV and content canary health check takes about 20 seconds, so Android's 15-second read
  timeout and the website's 8-second timeout could misreport a ready PC as offline. Decision:
  retain a 15-second endpoint-document connection timeout, allow 120-second Android API reads
  and 45-second web/GUI health reads, and cache only successful/failed health probes for 60
  seconds. Every uploaded photo is still scanned afresh.
- Plan: expose the service immediately after the local fix. Territory: opening a Quick Tunnel
  and changing the GitHub Pages endpoint publishes an upload address outside this PC. Decision:
  complete local health and upload/download verification first and keep the tracked endpoint
  offline until that outward-facing action is explicitly approved.

- Plan: use the TRIP Codex implementation delegate for the in-app creation feature. Territory:
  the delegate invocation was blocked because it would transmit repository contents to an
  external Codex API. Decision: keep all implementation work in the current local workspace and
  perform the same branch, self-review, test, and build gates directly.
- Plan: let phone users enter a processing URL. Territory: the requested flow starts from the
  project's GitHub site and an arbitrary URL would weaken the trusted discovery boundary.
  Decision: the Android app reads the fixed public `endpoint.json`, accepts only a live v1 HTTPS
  API with no credentials/query/fragment, and refuses creation until all three health gates are
  explicitly ready.
- Plan: reuse the website inside an embedded browser. Territory: a WebView would duplicate file
  handoff and make automatic strict package import less reliable. Decision: use Android platform
  networking directly while preserving the website's photo limits, endpoint rules, API contract,
  and strict `.vr3d` importer. Processing is foreground-only and bounded to 30 minutes; a device
  smoke remains required for picker and live tunnel behavior.
- Plan: run the checked-in Gradle wrapper for verification. Territory: its generated Windows
  launcher passes an empty `-classpath` value that Java 18 strips, and the sandbox user home
  cannot see the already cached Android plugin. Decision: run the same local Gradle 8.14 CLI JAR
  with the user's existing cache in offline mode; no dependency was downloaded.

- Plan: use the TRIP implementation scripts. Territory: this is a new repository without the
  TRIP `.claude` script bundle or an existing `docs/ARCHI.md`. Decision: create the architecture
  and plan documents here, use a dedicated Git branch, and apply the same self-review and test
  gates without fabricating missing TRIP state.
- Plan: build the APK from Android Studio. Territory: Android Studio is not installed, while the
  same Android Gradle Plugin 8.10.1 toolchain, SDK 36, Gradle 8.14, and JDK 17 are locally
  available. Decision: keep a standard Android Studio project and produce the APK with that
  local Gradle toolchain; record device/IDE-only checks separately.
- Plan: use the default Android path validation. Territory: the workspace has Korean characters
  and the Android Gradle Plugin blocks such Windows paths before compilation. Decision: enable
  `android.overridePathCheck=true`; all build/test outputs remain inside this project.
- Plan: run FastAPI and Video-Depth-Anything in one Python environment. Territory: the system
  Python has FastAPI but lacks `easydict`, while the untouched VR3D_v1 runtime has all VDA
  dependencies but lacks FastAPI. Decision: keep VR3D_v1 unchanged and isolate inference in a
  child worker launched with its existing virtual-environment Python.
- Plan: automatically update the published GitHub Pages endpoint. Territory: writing the local
  tracked `web/endpoint.json` is implemented, but committing or pushing it is an outward-facing
  publication requiring repository authentication and explicit approval. Decision: keep the
  checked-in endpoint offline and defer the GitHub push step; public upload remains unavailable.
- Plan: run Android tests directly in the Korean workspace path. Territory: AGP compilation works
  there after overriding its path check, but Gradle's Windows JUnit worker then loses the compiled
  test classes. Decision: perform verified builds through a temporary ASCII `R:` drive mapping to
  the same project and remove that mapping immediately after the build.
- Plan: use an `.mjs` browser module. Territory: the local Windows Python static server labels
  `.mjs` as `text/plain`, so the browser refuses to execute the page during end-to-end testing.
  Decision: rename the same ES module to `.js` under the package's `type: module` setting, which
  is also compatible with GitHub Pages.
- Plan: rely only on independently generated PC and Android fixtures. Territory: that leaves the
  cross-platform package boundary unexercised. Decision: keep one small VDA/PC-generated
  `.vr3d` as an Android JVM test resource and require the strict Android importer to accept it.
- Plan: rate-limit by the socket address. Territory: Quick Tunnel connects to localhost, so all
  public users would share one rate bucket. Decision: bind the API to localhost and prefer a
  syntactically valid Cloudflare `CF-Connecting-IP` value for the per-client limiter.
