# Local runtime components

These components make the three mandatory safety gates and the HTTPS Quick Tunnel runnable on
the current PC. They are excluded from Git and source archives because of their size.

| Component | Pinned source/version | Local path | Verified SHA-256 |
| --- | --- | --- | --- |
| Cloudflare Tunnel | `cloudflared` 2026.7.3 Windows amd64 | `bin/cloudflared.exe` | `8635DA433B6DF8194746E88ED9D2589566C20E38BFC2A80E431A348B7C765841` |
| ClamAV | 1.5.4 Windows x64 | `runtime/clamav-1.5.4.win.x64` | Release ZIP: `0D9E0228B2674137EA1A2853566C98A0278AD52AB2582C3D6DBD75373848C395` |
| ClamAV definitions | Official `freshclam` mirror; daily version 28089 on 2026-08-11 | `runtime/clamav-db` | Validated by `clamscan --version` and a clean canary scan |
| Content classifier | `onnx-community/nsfw_image_detection-ONNX`, revision `1ceb3c7fe1e9f3f2507e6df577437f23a9149fd5` | `models/nsfw_image_detection_onnx/onnx/model.onnx` | `A4316A4FB750169AC4FCABAABEE1FCBD982B0EE8C0CC63FE3E944954BB9A7D9C` |

The content gate verifies the full model hash on every process invocation and fails closed on
missing assets, inference errors, malformed output, or a score at or above the conservative
NSFW threshold of 0.20. ClamAV accepts only exit code 0 as clean. V3 remains an independent
real-time-process gate.

The ONNX model and ClamAV databases should be refreshed only as an explicit maintenance change:
pin the new revision, update hashes, rerun safe and blocking tests, and record the change in the
implementation ledger before public upload is enabled.
