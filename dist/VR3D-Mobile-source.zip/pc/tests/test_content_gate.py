from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest
from PIL import Image

from vr3d_pc.config import local_content_command, local_scanner_command
from vr3d_pc.content_gate import NSFW_THRESHOLD, nsfw_probability, prepare_image


def test_content_probability_blocks_nsfw_and_allows_normal_logits():
    safe = nsfw_probability(np.array([[8.0, -8.0]], dtype=np.float32))
    unsafe = nsfw_probability(np.array([[-8.0, 8.0]], dtype=np.float32))
    assert safe < NSFW_THRESHOLD
    assert unsafe >= NSFW_THRESHOLD


def test_content_probability_rejects_invalid_model_output():
    with pytest.raises(ValueError, match="invalid_model_output"):
        nsfw_probability(np.array([[float("nan"), 0.0]], dtype=np.float32))


def test_prepare_image_has_expected_normalized_tensor(tmp_path: Path):
    image = tmp_path / "safe.png"
    Image.new("RGB", (4, 2), (255, 128, 0)).save(image)
    tensor = prepare_image(image)
    assert tensor.shape == (1, 3, 224, 224)
    assert np.isfinite(tensor).all()
    assert tensor.min() >= -1.0
    assert tensor.max() <= 1.0


def test_local_runtime_commands_require_complete_assets(tmp_path: Path):
    assert local_scanner_command(tmp_path) == ()
    assert local_content_command(tmp_path, "python.exe") == ()

    scanner = tmp_path / "runtime" / "clamav-1.5.4.win.x64" / "clamscan.exe"
    scanner.parent.mkdir(parents=True)
    scanner.write_bytes(b"exe")
    database = tmp_path / "runtime" / "clamav-db"
    database.mkdir()
    for name in ("main.cvd", "daily.cvd"):
        (database / name).write_bytes(b"db")
    script = tmp_path / "vr3d_pc" / "content_gate.py"
    script.parent.mkdir()
    script.write_text("", encoding="utf-8")
    model = tmp_path / "models" / "nsfw_image_detection_onnx" / "onnx" / "model.onnx"
    model.parent.mkdir(parents=True)
    model.write_bytes(b"model")

    assert local_scanner_command(tmp_path)[0] == str(scanner)
    assert local_content_command(tmp_path, "python.exe")[-1] == "{path}"
