from __future__ import annotations

import argparse
import hashlib
import math
from pathlib import Path

import numpy as np
import onnxruntime as ort
from PIL import Image, UnidentifiedImageError

MODEL_SHA256 = "a4316a4fb750169ac4fcabaabee1fcbd982b0ee8c0cc63fe3e944954bb9a7d9c"
NSFW_THRESHOLD = 0.20


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def prepare_image(path: Path) -> np.ndarray:
    try:
        with Image.open(path) as opened:
            opened.load()
            image = opened.convert("RGB").resize((224, 224), Image.Resampling.BILINEAR)
    except (OSError, UnidentifiedImageError, Image.DecompressionBombError) as error:
        raise ValueError("invalid_image") from error
    values = np.asarray(image, dtype=np.float32) / 255.0
    values = (values - 0.5) / 0.5
    return np.transpose(values, (2, 0, 1))[None, ...]


def nsfw_probability(logits: np.ndarray) -> float:
    if logits.shape != (1, 2) or not np.isfinite(logits).all():
        raise ValueError("invalid_model_output")
    normal, nsfw = (float(value) for value in logits[0])
    pivot = max(normal, nsfw)
    normal_exp = math.exp(normal - pivot)
    nsfw_exp = math.exp(nsfw - pivot)
    return nsfw_exp / (normal_exp + nsfw_exp)


def classify(path: Path, model_path: Path) -> float:
    if not model_path.is_file() or _sha256(model_path) != MODEL_SHA256:
        raise ValueError("model_integrity")
    session = ort.InferenceSession(str(model_path), providers=["CPUExecutionProvider"])
    logits = session.run(["logits"], {"pixel_values": prepare_image(path)})[0]
    return nsfw_probability(logits)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("path", type=Path)
    args = parser.parse_args()
    try:
        probability = classify(args.path, args.model_dir / "onnx" / "model.onnx")
    except Exception:
        return 20
    return 0 if probability < NSFW_THRESHOLD else 10


if __name__ == "__main__":
    raise SystemExit(main())
