# VR3D Mobile PC service

Run `run_admin.bat` from Windows. The service intentionally remains closed to uploads until
all three mandatory gates report healthy: AhnLab V3 real-time processes, a second local file
scanner, and a content-safety scanner.

For an operator-approved unattended start, `python -m vr3d_pc.gui --start` opens the same GUI
and schedules its existing Start action. Closing the GUI or pressing Stop still terminates both
the API and tunnel and writes the local endpoint offline.

On this workstation the service automatically discovers the pinned local components below,
without modifying the existing VR3D_v1 installation:

- `runtime/clamav-*.win.x64/clamscan.exe` plus `runtime/clamav-db`
- `models/nsfw_image_detection_onnx/onnx/model.onnx`
- `bin/cloudflared.exe`

These large runtime files are intentionally excluded from Git and the source ZIP. Their exact
versions and integrity hashes are recorded in `RUNTIME_COMPONENTS.md`. Explicit environment
commands still take precedence over auto-discovery.

Configuration is through environment variables. Commands are JSON argument arrays with
exactly one `{path}` placeholder; they are executed without a shell. A zero exit code is the
only clean/safe result. Use absolute executable paths.

```powershell
$env:VR3D_SCANNER_COMMAND='["C:\\absolute\\scanner.exe","--scan","{path}"]'
$env:VR3D_CONTENT_COMMAND='["C:\\absolute\\content-check.exe","{path}"]'
$env:VR3D_CLOUDFLARED='C:\absolute\cloudflared.exe'
pc\run_admin.bat
```

The GUI tests both scanner commands against a local safe canary before `publicReady` can be
true. The first check can take about 20 seconds because it performs real scans; successful
health is cached for 60 seconds, while every uploaded file is still scanned independently.
On a Quick Tunnel URL, the GUI verifies local API health before atomically setting
`web/endpoint.json` online. Stopping the GUI writes an offline endpoint. It never commits or
pushes that file; GitHub publication remains a separately approved operation.

The API runs under the normal Python environment. If that environment lacks the model's
dependencies, depth inference automatically uses the untouched existing runtime at
`C:\Users\user\Documents\VR3D_v1_runtime\venv\Scripts\python.exe` in an isolated child
process. Inputs and results are stored below `pc/data` and removed after 24 hours by the
server cleanup loop.

Verification:

```powershell
cd pc
python -m compileall -q vr3d_pc tests
python -m pytest -q
```
