package io.github.honggi82.vr3dmobile.network

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.time.Instant

class Vr3dCreationClientTest {
    private val client = Vr3dCreationClient()

    @Test
    fun acceptsLiveVersionedHttpsEndpoint() {
        val endpoint = client.parseEndpoint(
            """{"api_version":"v1","online":true,"api_base":"https://node.example/","updated_at":null,"expires_at":"2030-01-01T00:00:00Z"}""",
            Instant.parse("2029-01-01T00:00:00Z"),
        )

        assertEquals("https://node.example", endpoint.apiBase)
    }

    @Test
    fun rejectsOfflineExpiredOrInsecureEndpoint() {
        val now = Instant.parse("2029-01-01T00:00:00Z")
        val offline = """{"api_version":"v1","online":false,"api_base":null,"updated_at":null,"expires_at":null}"""
        val expired = """{"api_version":"v1","online":true,"api_base":"https://node.example","updated_at":null,"expires_at":"2028-01-01T00:00:00Z"}"""
        val insecure = """{"api_version":"v1","online":true,"api_base":"http://node.example","updated_at":null,"expires_at":"2030-01-01T00:00:00Z"}"""

        assertEquals("endpoint_offline", assertThrows(CreationException::class.java) { client.parseEndpoint(offline, now) }.code)
        assertEquals("endpoint_offline", assertThrows(CreationException::class.java) { client.parseEndpoint(expired, now) }.code)
        assertEquals("endpoint_insecure", assertThrows(CreationException::class.java) { client.parseEndpoint(insecure, now) }.code)
    }

    @Test
    fun parsesBoundedJobProgressAndFailureCode() {
        val state = client.parseJob(
            """{"jobId":"00000000-0000-0000-0000-000000000001","status":"failed","progress":61,"createdAt":"2029-01-01T00:00:00Z","expiresAt":"2029-01-02T00:00:00Z","errorCode":"content_rejected","downloadUrl":null}""",
        )

        assertEquals("failed", state.status)
        assertEquals(61, state.progress)
        assertEquals("content_rejected", state.errorCode)
    }

    @Test
    fun rejectsFractionalJobProgress() {
        val json = """{"status":"processing","progress":1.5,"errorCode":null}"""

        assertEquals(
            "job_response_invalid",
            assertThrows(CreationException::class.java) { client.parseJob(json) }.code,
        )
    }
}
