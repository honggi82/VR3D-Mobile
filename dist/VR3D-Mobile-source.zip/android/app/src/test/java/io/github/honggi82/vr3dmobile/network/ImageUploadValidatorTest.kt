package io.github.honggi82.vr3dmobile.network

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.nio.file.Files

class ImageUploadValidatorTest {
    @get:Rule
    val temporary = TemporaryFolder()

    @Test
    fun acceptsMatchingJpegMetadataAndSignature() {
        val path = temporary.newFile("photo.jpg").toPath()
        Files.write(path, byteArrayOf(0xff.toByte(), 0xd8.toByte(), 0xff.toByte(), 0x00))

        val image = ImageUploadValidator.validate(path, "photo.jpg", "image/jpeg")

        assertEquals("upload.jpg", image.serverFilename)
        assertEquals("image/jpeg", image.mimeType)
    }

    @Test
    fun rejectsExtensionOrMimeThatDoesNotMatchBytes() {
        val path = temporary.newFile("photo.bin").toPath()
        Files.write(path, byteArrayOf(0xff.toByte(), 0xd8.toByte(), 0xff.toByte(), 0x00))

        assertEquals(
            "image_extension_mismatch",
            assertThrows(CreationException::class.java) {
                ImageUploadValidator.validate(path, "photo.png", "image/png")
            }.code,
        )
    }
}
