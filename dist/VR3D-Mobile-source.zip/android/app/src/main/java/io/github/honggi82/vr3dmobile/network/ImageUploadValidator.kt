package io.github.honggi82.vr3dmobile.network

import java.nio.file.Files
import java.nio.file.Path

data class UploadImage(val path: Path, val serverFilename: String, val mimeType: String)

object ImageUploadValidator {
    const val MAX_IMAGE_BYTES = 25L * 1024 * 1024

    private data class Format(
        val extensions: Set<String>,
        val mimeType: String,
        val serverFilename: String,
    )

    private val jpeg = Format(setOf("jpg", "jpeg"), "image/jpeg", "upload.jpg")
    private val png = Format(setOf("png"), "image/png", "upload.png")
    private val webp = Format(setOf("webp"), "image/webp", "upload.webp")

    fun validate(path: Path, displayName: String?, reportedMimeType: String?): UploadImage {
        val name = displayName ?: throw CreationException("image_name_invalid")
        if (name.isBlank() || name != name.substringAfterLast('/') || name != name.substringAfterLast('\\')) {
            throw CreationException("image_name_invalid")
        }
        val size = Files.size(path)
        if (size !in 1..MAX_IMAGE_BYTES) throw CreationException("image_size_invalid")

        val header = ByteArray(12)
        val count = Files.newInputStream(path).use { it.read(header) }
        val format = when {
            count >= 3 && header[0] == 0xff.toByte() && header[1] == 0xd8.toByte() && header[2] == 0xff.toByte() -> jpeg
            count >= 8 && header.copyOfRange(0, 8).contentEquals(PNG_SIGNATURE) -> png
            count >= 12 && header.copyOfRange(0, 4).decodeToString() == "RIFF" &&
                header.copyOfRange(8, 12).decodeToString() == "WEBP" -> webp
            else -> throw CreationException("image_signature_invalid")
        }

        val extension = name.substringAfterLast('.', "").lowercase()
        if (extension !in format.extensions) throw CreationException("image_extension_mismatch")
        if (reportedMimeType?.lowercase() != format.mimeType) throw CreationException("image_mime_mismatch")
        return UploadImage(path, format.serverFilename, format.mimeType)
    }

    private val PNG_SIGNATURE = byteArrayOf(
        0x89.toByte(), 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
    )
}
