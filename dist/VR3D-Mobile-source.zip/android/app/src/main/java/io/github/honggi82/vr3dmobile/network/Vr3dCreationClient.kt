package io.github.honggi82.vr3dmobile.network

import io.github.honggi82.vr3dmobile.domain.JsonBoolean
import io.github.honggi82.vr3dmobile.domain.JsonNull
import io.github.honggi82.vr3dmobile.domain.JsonNumber
import io.github.honggi82.vr3dmobile.domain.JsonObject
import io.github.honggi82.vr3dmobile.domain.JsonString
import io.github.honggi82.vr3dmobile.domain.StrictJson
import io.github.honggi82.vr3dmobile.domain.objectValue
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardOpenOption
import java.time.Instant
import java.util.UUID

class CreationException(val code: String, cause: Throwable? = null) : IOException(code, cause)

data class EndpointConfig(val apiBase: String)
data class JobState(val status: String, val progress: Int, val errorCode: String?)

class Vr3dCreationClient(
    private val endpointDocumentUrl: String = DEFAULT_ENDPOINT_URL,
) {
    fun create(
        image: UploadImage,
        downloadTarget: Path,
        onProgress: (stage: String, progress: Int) -> Unit,
    ) {
        checkInterrupted()
        onProgress("checking", 0)
        val endpoint = parseEndpoint(getJson(endpointDocumentUrl, 64 * 1024, CONNECT_TIMEOUT_MILLIS))
        requireHealthy(endpoint)

        checkInterrupted()
        onProgress("uploading", 2)
        val jobId = createJob(endpoint, image)
        val deadline = System.nanoTime() + POLL_TIMEOUT_NANOS
        while (true) {
            checkInterrupted()
            val state = getJob(endpoint, jobId)
            when (state.status) {
                "complete" -> break
                "failed" -> throw CreationException(state.errorCode ?: "job_failed")
                "queued", "scanning", "processing" -> onProgress("processing", state.progress)
                else -> throw CreationException("job_response_invalid")
            }
            if (System.nanoTime() >= deadline) throw CreationException("job_timeout")
            try {
                Thread.sleep(POLL_INTERVAL_MILLIS)
            } catch (error: InterruptedException) {
                Thread.currentThread().interrupt()
                throw CreationException("cancelled", error)
            }
        }

        checkInterrupted()
        onProgress("downloading", 100)
        download(endpoint, jobId, downloadTarget)
    }

    internal fun parseEndpoint(json: String, now: Instant = Instant.now()): EndpointConfig {
        val root = StrictJson.parse(json).objectValue("endpoint")
        if (root.boolean("online") != true) throw CreationException("endpoint_offline")
        if (root.string("api_version") != "v1") throw CreationException("endpoint_version")
        root.stringOrNull("expires_at")?.let {
            val expiresAt = try {
                Instant.parse(it)
            } catch (error: Exception) {
                throw CreationException("endpoint_offline", error)
            }
            if (!expiresAt.isAfter(now)) throw CreationException("endpoint_offline")
        }

        val rawBase = root.string("api_base") ?: throw CreationException("endpoint_invalid")
        val uri = try {
            URI(rawBase)
        } catch (error: Exception) {
            throw CreationException("endpoint_invalid", error)
        }
        if (uri.scheme != "https" || uri.host.isNullOrBlank() || uri.userInfo != null ||
            uri.query != null || uri.fragment != null
        ) {
            throw CreationException("endpoint_insecure")
        }
        val path = (uri.path ?: "").trimEnd('/')
        val normalized = URI("https", null, uri.host, uri.port, path, null, null).toString()
        return EndpointConfig(normalized)
    }

    internal fun parseJob(json: String): JobState {
        val root = StrictJson.parse(json).objectValue("job")
        val status = root.string("status") ?: throw CreationException("job_response_invalid")
        val progress = try {
            (root.values["progress"] as? JsonNumber)?.value?.intValueExact() ?: 0
        } catch (error: ArithmeticException) {
            throw CreationException("job_response_invalid", error)
        }
        if (progress !in 0..100) throw CreationException("job_response_invalid")
        return JobState(status.lowercase(), progress, root.stringOrNull("errorCode"))
    }

    private fun requireHealthy(endpoint: EndpointConfig) {
        val root = StrictJson.parse(getJson(apiUrl(endpoint, "/api/v1/health"), 64 * 1024)).objectValue("health")
        if (root.boolean("publicReady") != true) throw CreationException("gates_unavailable")
        val gates = (root.values["gates"] as? JsonObject) ?: throw CreationException("health_invalid")
        for (name in listOf("v3", "scanner", "content")) {
            val gate = (gates.values[name] as? JsonObject) ?: throw CreationException("health_invalid")
            if (gate.boolean("ready") != true) throw CreationException("gates_unavailable")
        }
    }

    private fun createJob(endpoint: EndpointConfig, image: UploadImage): String {
        val boundary = "vr3d-${UUID.randomUUID()}"
        val prefix = (
            "--$boundary\r\n" +
                "Content-Disposition: form-data; name=\"quality\"\r\n\r\n" +
                "vitl\r\n" +
                "--$boundary\r\n" +
                "Content-Disposition: form-data; name=\"file\"; filename=\"${image.serverFilename}\"\r\n" +
                "Content-Type: ${image.mimeType}\r\n\r\n"
            ).toByteArray(StandardCharsets.US_ASCII)
        val suffix = "\r\n--$boundary--\r\n".toByteArray(StandardCharsets.US_ASCII)
        val contentLength = prefix.size.toLong() + Files.size(image.path) + suffix.size
        val connection = open(apiUrl(endpoint, "/api/v1/jobs"), "POST", READ_TIMEOUT_MILLIS).apply {
            doOutput = true
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            setFixedLengthStreamingMode(contentLength)
        }
        try {
            BufferedOutputStream(connection.outputStream).use { output ->
                output.write(prefix)
                Files.newInputStream(image.path).use { input -> input.copyTo(output) }
                output.write(suffix)
            }
            val json = responseText(connection, 64 * 1024, setOf(202))
            val root = StrictJson.parse(json).objectValue("create job")
            val jobId = root.string("jobId") ?: throw CreationException("job_response_invalid")
            try {
                UUID.fromString(jobId)
            } catch (error: IllegalArgumentException) {
                throw CreationException("job_response_invalid", error)
            }
            return jobId
        } finally {
            connection.disconnect()
        }
    }

    private fun getJob(endpoint: EndpointConfig, jobId: String): JobState =
        parseJob(getJson(apiUrl(endpoint, "/api/v1/jobs/$jobId"), 64 * 1024))

    private fun download(endpoint: EndpointConfig, jobId: String, target: Path) {
        val connection = open(apiUrl(endpoint, "/api/v1/jobs/$jobId/download"), "GET", READ_TIMEOUT_MILLIS)
        try {
            if (connection.responseCode != 200) throw CreationException(errorCode(connection))
            val type = connection.contentType?.substringBefore(';')?.trim()?.lowercase()
            if (type != "application/vnd.vr3d+zip" && type != "application/octet-stream") {
                throw CreationException("download_type_invalid")
            }
            val declared = connection.contentLengthLong
            if (declared <= 0 || declared > MAX_PACKAGE_BYTES) throw CreationException("download_size_invalid")
            BufferedInputStream(connection.inputStream).use { input ->
                Files.newOutputStream(target, StandardOpenOption.CREATE_NEW).use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    var total = 0L
                    while (true) {
                        checkInterrupted()
                        val read = input.read(buffer)
                        if (read < 0) break
                        total += read
                        if (total > MAX_PACKAGE_BYTES) throw CreationException("download_size_invalid")
                        output.write(buffer, 0, read)
                    }
                    if (total <= 0) throw CreationException("download_size_invalid")
                }
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun getJson(url: String, limit: Int, readTimeout: Int = READ_TIMEOUT_MILLIS): String {
        val connection = open(url, "GET", readTimeout)
        return try {
            responseText(connection, limit, setOf(200))
        } finally {
            connection.disconnect()
        }
    }

    private fun responseText(connection: HttpURLConnection, limit: Int, accepted: Set<Int>): String {
        val code = connection.responseCode
        if (code !in accepted) throw CreationException(errorCode(connection))
        val contentLength = connection.contentLengthLong
        if (contentLength > limit) throw CreationException("response_too_large")
        return readLimited(connection.inputStream, limit)
    }

    private fun errorCode(connection: HttpURLConnection): String {
        val fallback = "http_${connection.responseCode}"
        val stream = connection.errorStream ?: return fallback
        return try {
            val root = StrictJson.parse(readLimited(stream, 64 * 1024)).objectValue("error")
            val detail = root.values["detail"] as? JsonObject
            detail?.string("code") ?: fallback
        } catch (_: Exception) {
            fallback
        }
    }

    private fun readLimited(input: java.io.InputStream, limit: Int): String {
        input.use {
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            var total = 0
            while (true) {
                val read = it.read(buffer)
                if (read < 0) break
                total += read
                if (total > limit) throw CreationException("response_too_large")
                output.write(buffer, 0, read)
            }
            return output.toString(StandardCharsets.UTF_8.name())
        }
    }

    private fun open(url: String, method: String, readTimeout: Int): HttpURLConnection {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = method
        connection.connectTimeout = CONNECT_TIMEOUT_MILLIS
        connection.readTimeout = readTimeout
        connection.instanceFollowRedirects = false
        connection.useCaches = false
        connection.setRequestProperty("Accept", "application/json")
        return connection
    }

    private fun apiUrl(endpoint: EndpointConfig, path: String) = endpoint.apiBase + path

    private fun checkInterrupted() {
        if (Thread.currentThread().isInterrupted) throw CreationException("cancelled")
    }

    private fun JsonObject.string(name: String): String? = (values[name] as? JsonString)?.value

    private fun JsonObject.stringOrNull(name: String): String? = when (val value = values[name]) {
        is JsonString -> value.value
        JsonNull, null -> null
        else -> throw CreationException("response_invalid")
    }

    private fun JsonObject.boolean(name: String): Boolean? = (values[name] as? JsonBoolean)?.value

    companion object {
        const val DEFAULT_ENDPOINT_URL = "https://honggi82.github.io/VR3D-Mobile/endpoint.json"
        private const val CONNECT_TIMEOUT_MILLIS = 15_000
        private const val READ_TIMEOUT_MILLIS = 120_000
        private const val POLL_INTERVAL_MILLIS = 2_000L
        private const val POLL_TIMEOUT_NANOS = 30L * 60 * 1_000_000_000
        private const val MAX_PACKAGE_BYTES = 512L * 1024 * 1024
    }
}
