# Verification Report — 2026-08-12

## Verified

- PC: `python -m compileall -q vr3d_pc tests` passed.
- PC: `python -m pytest -q` passed, 20 tests; one non-blocking Starlette/httpx
  deprecation warning.
- Live local API: `/api/v1/health` returned `publicReady:true`, with V3, ClamAV, and
  content safety all reporting `{ready:true, code:"ok"}`.
- Live local creation: a 96×64 WebP passed the mandatory gates, ran real `vits` depth
  inference, generated 35 views, reached `complete:100`, and downloaded a 75,065-byte
  `.vr3d` package with SHA-256
  `87089F596353572E754CE93B2C2EDA468C7D196A3CF46AFB121860521C900A64`.
- Real depth: untouched VR3D_v1 runtime, CUDA, `vits`, 96×64 RGB input produced a finite
  float32 64×96 map normalized to `[0, 1]`.
- Cross-component package: real depth plus 35 rendered views produced a 38-entry `.vr3d`
  ZIP (manifest plus 37 hashed payloads), validated against package schema v1.
- Android: the strict Kotlin importer accepted that PC-generated package fixture.
- Android: `testDebugUnitTest` passed 16/16, including six in-app creation protocol/image
  validation tests; `lintDebug` completed with 0 errors and
  2 non-blocking warnings; `assembleDebug` succeeded.
- APK: package `io.github.honggi82.vr3dmobile`, version 1.0.0, minSdk 29, targetSdk 36;
  debug APK Signature Scheme v2 verification passed.
- Web: Node tests passed 7/7. Chromium showed the offline state with the create button
  disabled, rejected a text payload disguised as PNG, and reported 0 console errors.
- Safety: live V3 process health passed; pinned ClamAV 1.5.4 performed a real clean-file
  scan; the pinned standard ONNX content model loaded on the CPU provider and passed the
  safe canary. Content-gate threshold, malformed output, non-finite output, and runtime
  discovery behavior are covered by automated tests.
- Published discovery: `https://honggi82.github.io/VR3D-Mobile/endpoint.json` returned HTTP 200
  with `online:false`; the Android parser rejects that state before any photo upload.
- Retention, rate limiting, failed-quarantine deletion, ZIP traversal, compression ratio,
  strict manifest keys, and SHA-256 mismatch behavior are covered by automated tests.

## Not verified / intentionally blocked

- No physical Android device is connected, so APK installation, the photo picker and live
  upload/poll/download/import flow, real sensor axes, orientation feel, memory behavior, and
  Android file association are not device-tested.
- Pinned `cloudflared` is installed and its SHA-256 and Authenticode signature were verified,
  but a public Quick Tunnel was intentionally not opened without outward-publication approval.
- The GitHub Pages endpoint still advertises `online:false`; an installed app will continue to
  fail closed until the approved tunnel URL is published there.
- The Tkinter GUI was code- and helper-tested but not visually exercised in this session.
- GitHub Pages and the repository were published earlier. This feature branch and its updated
  APK/source archive have not been pushed because a new outward publication requires approval.

## Artifact

- APK SHA-256: `59F5E92B7E16EF6F48085F7634CE093B03D2DC06AFDD8DE78B3666CC047D15EF`
